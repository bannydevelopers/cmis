<?php 

echo helper::find_template('project_details', []);