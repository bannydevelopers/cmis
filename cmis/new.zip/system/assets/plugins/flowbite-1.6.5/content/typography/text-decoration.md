---
layout: home
title: Tailwind CSS Text Decoration - Flowbite
description: Use the typography plugin from Flowbite to apply styles to all inline elements like headings, paragraphs, lists, and images using a single format class
group: typography
toc: true

previous: List group
previousLink: components/list-group/
next: Modals
nextLink: components/modal/
---

