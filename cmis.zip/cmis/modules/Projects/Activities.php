<?php 

echo helper::find_template('activities', []);