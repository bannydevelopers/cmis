<?php 

echo helper::find_template('home', ['msg'=>'I\'m home, dude!']);