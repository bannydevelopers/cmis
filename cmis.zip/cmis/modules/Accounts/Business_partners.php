<?php 

echo helper::find_template('Business_partners', []);