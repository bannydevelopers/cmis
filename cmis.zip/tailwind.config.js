module.exports = {
  content: ["./cmis/system/templates/**/*.html"],
  darkMode: 'class',
  theme: {
    extend: {
      screens: {
        'mob': '580px'
      }
    },
  },
  plugins: [],
}