# Unfinished business back-end
## Message
- failure message identifier in every module

## LogIn
- count attemts and block user for some minutes

## Dashboard
- cards real data

## HR
### Staff
- designatins list options on add staff are not all shown 










# Unfinished business front-end
- password and confirm password match
- print invoice
- table filter
- table pagination