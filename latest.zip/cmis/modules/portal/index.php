<?php
header('Location: ./admin');