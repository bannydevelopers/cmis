<?php 

echo helper::find_template('Payment_gateway', []);